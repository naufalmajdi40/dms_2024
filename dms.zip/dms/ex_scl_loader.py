""" pip install scl_loader """
import scl_loader
import db
#scl_path = "sel.iid"
#scl_path = "P141.icd"
scl_path="/var/www/html/dms_setting//upload"
import time
# scd = scl_loader.SCD_handler(scl_path, False)

# ied_name = scd.get_IED_names_list()
# ied_name = ied_name[0]
# ied = scd.get_IED_by_name(ied_name)
# ip = scd.get_IP_Adr(ied_name)
# print(ip)


class IED_PARSING:
    def __init__(self, filePath, LDFilter):
        self.LDFilter = LDFilter
        self.filePath = filePath
        self.scd = scl_loader.SCD_handler(self.filePath, False)
        self.iedName = self.scd.get_IED_names_list()
        self.iedName = self.iedName[0]
        self.ied = self.scd.get_IED_by_name(self.iedName)
        self.ip = self.scd.get_IP_Adr(self.iedName)
        self.ap = self.ip[1]
        self.ip = self.ip[0]
        self.LDobj = self.ied.get_LD_by_inst(LDFilter, self.ip)
        self.DAobj = self.ied.get_DA_leaf_nodes()

    def getIEDName(self):
        return self.iedName, self.ap

    def getIP(self):
        return self.ip

    # def LD_obj(self):
    #     self.LD = self.ied.get_LD_by_inst(LDFilter, self.ip)

    # def getKeyLD_obj(self):
    #     return self.LD.k

    # def LN_obj(self):

    # def DO_obj(self):

    def DA_obj(self):
        # print(self.DAobj.keys())
        return [x for x in list(self.DAobj.keys()) if self.LDFilter in x]

    def DomainID(self):
        return self.iedName+self.LDFilter

    def makeItemID(self, DA, FC):
        obj = DA.split(".")
        obj[1] += '$' + FC
        return "$".join(obj[1:])

    def filterMeasurement(self, data, filter: str):
        return [x for x in data if filter in x]


def makeItemID(DA, FC):
    obj = DA.split(".")
    obj[1] += '$' + FC
    return "$".join(obj[1:])

def runLoader(scl_path,id):
    ied1 = IED_PARSING(scl_path, 'MET')
    #print(ied1.DomainID())
    da_obj = ied1.DA_obj()
    db.deleteDb.it_file_iec_delete_by_id(0,id)
    for i in range(len(da_obj)):
        buffItem=makeItemID(da_obj[i], 'MX')
        try:
            buffSplit = buffItem.split("$")
            itemId=makeItemID(da_obj[i], 'MX')
            domainId=ied1.DomainID()
            ip= ied1.getIP()
            print(ip)
            db.insertDb.m_file_iec_insert(0,domainId,itemId, ip,2)
            time.sleep(0.001)
            


        except:
            #db.updateDb.scl_flag(1,2,2)
            print("err")
#runLoader(scl_path,2)
while True:
    device_list = db.readDb.device_list(1)
    print("read Db")

    for i in range(len(device_list)):
        if(device_list[i]['scl_flag']==1):
            if(device_list[i]['scl_name']!=None):
                loc=scl_path+"/"+device_list[i]['scl_name']
                try:
                    runLoader(loc,2)
                    db.updateDb.scl_flag(1,2,2)
                except:
                    db.updateDb.scl_flag(1,3,2)
                
                
                print(loc)
            time.sleep(0.1)
    time.sleep(3)

    #print(makeItemID(da_obj[i], 'MX'))

# da_list = ied.get_DA_leaf_nodes()
# # print("Key:", list(da_list.keys()))

# do_list = ied.get_DO_nodes()
# # print("Key:", list(do_list.keys()))


# ld_inst = 'Measurements'

# Ld_all = ied.get_LD_by_inst(ld_inst, ip[1])

# ln_name = 'PriRmsMMXU1'
# Ld_all = ied.get_LN_by_name(ld_inst, ln_name, ip[1])
# # print(Ld_all)


# Ld = ied.get_LD_by_inst(ld_inst, ip[1])
# Ln = Ld.get_LN_by_name('PriRmsMMXU1')

# DA_dic = Ln.get_DA_leaf_nodes()

# # print("DA Key:", list(DA_dic.keys()))
# Do_node = Ln.get_DO_nodes()
# print("Do Key:", list(Do_node.keys()))


# print(strr)
