""" pip install scl_loader """
import scl_loader
import scl_loader.scl_loader as scdl
from scl_loader import SCD_handler
from scl_loader import IED
from scl_loader import LD
from scl_loader import LN
from scl_loader import LN0
from scl_loader import DO
from scl_loader import DA
from scl_loader import SCDNode
from scl_loader import DataTypeTemplates
from scl_loader import ServiceType


scl_path = "P141.icd"
SCD_HANDLER = SCD_handler(scl_path)
scd = scl_loader.SCD_handler(scl_path, False)

ied_name = scd.get_IED_names_list()
ied_name = ied_name[0]
ied = scd.get_IED_by_name(ied_name)
ip = scd.get_IP_Adr(ied_name)
# ied = SCD_HANDLER.get_IED_by_name('AUT1A_SITE_1')
print(ied)


class IED_PARSING:
    def __init__(self, filePath, LDFilter):
        self.LDFilter = LDFilter
        self.filePath = filePath
        self.scd = scl_loader.SCD_handler(self.filePath, False)
        self.iedName = self.scd.get_IED_names_list()
        self.iedName = self.iedName[0]
        self.ied = self.scd.get_IED_by_name(self.iedName)
        self.ip = self.scd.get_IP_Adr(self.iedName)
        self.ap = self.ip[1]
        self.ip = self.ip[0]
        self.LDobj = self.ied.get_LD_by_inst(LDFilter, self.ip)
        self.DAobj = self.ied.get_DA_leaf_nodes()
              
    # def getFC(self):
        
    #     print(self.ied.get_name_subtree('MX'))

    def getIEDName(self):
        return self.iedName, self.ap

    def getIP(self):
        return self.ip

    # def LD_obj(self):
    #     self.LD = self.ied.get_LD_by_inst(LDFilter, self.ip)

    # def getKeyLD_obj(self):
    #     return self.LD.k

    # def LN_obj(self):

    # def DO_obj(self):

    def DA_obj(self):
        # print(self.DAobj.keys())
        return [x for x in list(self.DAobj.keys()) if self.LDFilter in x]

    def DomainID(self):
        return self.iedName+self.LDFilter

    def makeItemID(self, DA, FC):
        obj = DA.split(".")
        obj[1] += '$' + FC
        return "$".join(obj[1:])
    
    def getItemID(self, FC=None):
        item = []
        if FC == None:
            for k, fc in self.DAobj.items():
                # if 'Measurement' in k:
                obj = k.split(".")
                obj[1] += '$' + fc.get_associated_fc()
                item.append("$".join(obj[1:]))
                # return item
        else:
            for k, fc in self.DAobj.items():
                if FC in k:
                    obj = k.split(".")
                    obj[1] += '$' + fc.get_associated_fc()
                    item.append("$".join(obj[1:]))
        return item
        # if FC == None:
        # obj = DA.split(".")
        # obj[1] += '$' + FC
        # return "$".join(obj[1:])

    def filterMeasurement(self, data, filter: str):
        return [x for x in data if filter in x]


def makeItemID(DA, FC):
    obj = DA.split(".")
    obj[1] += '$' + FC
    return "$".join(obj[1:])


ied1 = IED_PARSING(scl_path, 'Measurement')
# print(ied1.DomainID())
# da_obj = ied1.DA_obj()
print(ied1.getItemID('Measurements'))

# for i in range(len(da_obj)):
#     print(makeItemID(da_obj[i], 'MX'))

# da_list = ied.get_DA_leaf_nodes()
# # print("Key:", list(da_list.keys()))

# do_list = ied.get_DO_nodes()
# # print("Key:", list(do_list.keys()))


# ld_inst = 'Measurements'
# ln_name = 'PriRmsMMXU1'
# Ld_all = ied.get_LN_by_name(ld_inst, ln_name, ip[1])
# # print(Ld_all)


# Ld = ied.get_LD_by_inst(ld_inst, ip[1])
# print(Ld)
# Ln = Ld.get_LN_by_name('PriRmsMMXU1')
# print(Ln)


# print(l.ied.get_name_subtree('MX'))

### GET ALL TREE NODE ####
# Do_node = Ln.get_DO_nodes()
# # Do_node
# da_list = ied.get_DA_leaf_nodes()
# # print("Key:", list(da_list.items()))
# key =[]
# fc = []
# for k, fc in da_list.items():
#     if 'Measurement' in k:
#         obj = k.split(".")
#         obj[1] += '$' + fc.get_associated_fc()
#         print("$".join(obj[1:]))
        

# # print("DA Key:", list(DA_dic.keys()))
# Do_node = Ln.get_DO_nodes()
# print("Do Key:", list(Do_node.keys()))


# print(strr)
