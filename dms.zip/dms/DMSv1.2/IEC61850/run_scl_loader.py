import time
import db
import ex_scl_loader as loader
import json
import os
scl_path="/var/www/html/dms_setting/upload"
path="/var/www/html/dms_setting/assets/scl/"
def saveToFile(data, filePath):
        global path
        f = open(path+filePath+".json", "w")
        f.write(data)
        f.close()
def toJson(data,name):
    global file_path
    jsonData=[]
    #print(data)
    for i in range(len(data)):
        buf = data[i].split("-")
        x={"id":f"{i}","domain_id":buf[0],"item_id":buf[1],"all":buf[0]+"$"+buf[1]}
        jsonData.append(x)
    data= json.dumps(jsonData)
    saveToFile(data, name)
    print(name)
    
def toJson2(jsonData,name):
    global file_path
    #print(data)
    data= json.dumps(jsonData)
    saveToFile(data, name)
    print(name)
    
while True:
    device_list=db.readDb.device_list(1)
    cfg = db.readDb.flag_config(1)
    
    cfg_flag=cfg[0]["flag_program_iec"]
    print(cfg_flag)
    if(cfg_flag==1):
        print("restart program")
        os.popen("pm2 restart all")
        db.updateDb.flag_config(1,0)
        time.sleep(1)
    #print(cfg_flag)
    for i in range(len(device_list)):
       # print(device_list[i]['scl_flag'])
        if(device_list[i]['scl_flag']==1):
            print("upload woy")
            if(device_list[i]['scl_name']!=None):
                loc=scl_path+"/"+device_list[i]['scl_name']
                print(loc)
                id_device=device_list[i]['id_device']
                try:
                    ied1=loader.IED_PARSING(loc)
                    #all_domain = ied1.getAllDomainID()
                    #print(all_domain)
                    #toJson(all_domain,device_list[i]['id_device'])
                    print(ied1.all_domain_dict)
                    toJson2(ied1.all_domain_dict,device_list[i]['id_device'])
                    db.updateDb.scl_flag(1,2,id_device)
                    print(id_device)
                except :
                    # print(NameError)
                     print("gagal baca scl")
                     db.updateDb.scl_flag(1,3,id_device)
                #print(all_domain)
            time.sleep(1)
    time.sleep(5)
