from time import time
from pymodbus.client.sync import ModbusSerialClient as ModbusClient
from pymodbus.payload import BinaryPayloadDecoder
from pymodbus.constants import Endian

# import init_copy as main_init
# import micomp123 as micomp123
import time
import struct
from datetime import datetime, timedelta

cekStatus = ModbusClient(method='rtu', port='/dev/ttyUSB0',  stopbits = 1 , bytesize = 8, parity = 'N',baudrate= 19200, timeout=1)
connection = cekStatus.connect()
readData = cekStatus.read_holding_registers(address = 15616, count = 36,unit= 1)
read_milis_atas = cekStatus.read_holding_registers(address = 400, count = 1,unit= 1)
 
if readData.isError():
    # print('Port'+str(micomp123.indexMaster[self.index][self.idPort])+' RS-485 tidak dapat menerima data')
    print('Port'+str(0)+' RS-485 tidak dapat menerima data')
    
else:
    #print(readData.registers)
    #print( '-'.join( '%02x' % x for x in hexdata ) )
    
    reg_milis_atas = read_milis_atas.registers[0]
    milis_atas = reg_milis_atas/10
    print(milis_atas)
    millis_bawah = readData.registers[33]
    print(millis_bawah)
    
    second_1 = hex(readData.registers[31])[2:]
    second_2 = hex(readData.registers[32])[2:]
    second_1f = second_1.rjust(4,'0')
    second_2f = second_2.rjust(4,'0')
    
    
    
    secTot = struct.unpack('>i', bytes.fromhex(second_1f + second_2f))
    base_date = datetime(1994,1,1)
    dateNow = base_date + timedelta(seconds=int(secTot[0]))
    print(dateNow.strftime("%Y/%m/%d %H:%M:%S"))
    waktu_bawah = dateNow+timedelta(milliseconds=millis_bawah)
    waktu_atas = waktu_bawah - timedelta(seconds=milis_atas) + timedelta(milliseconds= -1)
    print(waktu_atas)
    print(waktu_bawah)
    
    
    