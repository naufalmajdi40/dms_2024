from ast import Name

import asyncio
import json
#import grequests
from time import gmtime, strftime
import requests
from datetime import datetime
from pymysqlpool.pool import Pool
import pymysql.cursors

pool = Pool(host='localhost', port=3306, user='user', password='mgi', db='dms')
db=[0]*5
for i in range(3):
    db[i] = pool.get_conn()

url=[]
def queryData(x,query):
    global db
    global pool
    try:
        cursor = db[x].cursor()
        cursor.execute(query)
        result = cursor.fetchall()     
        db[x].commit()
        cursor.close()
        pool.release(db[x])
        db[i] = pool.get_conn()
        #print(result)
        return result 
    
    except NameError:
        print(NameError)
class updateDb:
    def scl_flag(x,flag,id):
        query= f"UPDATE device_list set scl_flag = "+str(flag) +" where id_device = "+str(id)
        print(query)
        try:
            results =queryData(x,query)
            return results
        except:
            print("eror query")
class readDb:
    def m_file_iec_read_by_active(x):
        query= f"select * from m_file_iec where active =1"
        try:
           results =queryData(x,query)
           return results
        except:
            print("eror query")
    def device_list_by_mode(x):
        query= f"select * from device_list where mode=2"
        try:
            results =queryData(x,query)
            return results
        except:
            print("eror query")
    def device_list(x):
        query= f"select * from device_list "
        try:
            results =queryData(x,query)
            return results
        except:
            print("eror query")
class insertDb:
    def __init__(self,index):
        self.index = index
    def m_file_iec_insert(x,domainId,itemId,ip,relayId):
        query= f"insert into it_file_iec (domain_id,item_id,id_device,ip_address) values('{domainId}','{itemId}','{relayId}','{ip}')"
        #print(query)
        results =queryData(x,query)
        # try:
        #    results =queryData(x,query)
        #    return results
        # except:
        #     print("eror query")
class deleteDb:
    def __init__(self,index):
        self.index = index
    def m_file_iec_delete_by_domain_id(x,domainId):
        query= f"delete from  it_file_iec where id_device='{domainId}'"
        #print(query)
        
        try:
           results =queryData(x,query)
           return results
        except:
            print("eror query")

